log_requests
stdout_redirect "t1-stdout"
pidfile "t1-pid"
