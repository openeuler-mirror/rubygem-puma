prune_bundler true
extra_runtime_dependencies ["rdoc"]
