### Steps to reproduce

1) ...

2) ...

3) ...

### Expected behavior

Tell us what should happen ...

### Actual behavior

Tell us what happens instead ...

### System configuration

**Ruby version**:
**Rails version**:
**Puma version**:
